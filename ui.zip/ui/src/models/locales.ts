export type Locales = 'en' | 'ru';
