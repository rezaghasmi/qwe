export type BorderRadius = 'm' | 's' | 'none';
