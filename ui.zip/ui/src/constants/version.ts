declare const TON_CONNECT_UI_VERSION: string;

export const tonConnectUiVersion: string = TON_CONNECT_UI_VERSION;
