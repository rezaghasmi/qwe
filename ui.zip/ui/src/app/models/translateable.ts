export interface Translateable {
    translationKey?: string;
    translationValues?: Record<string, string>;
}
