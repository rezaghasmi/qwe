document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('connectWallet').addEventListener('click', async () => {
        const statusElement = document.getElementById('status');
        
        try {
            // Dynamically load the TonConnect script
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/@tonconnect/sdk@latest/dist/tonconnect.min.js';
            script.onload = async () => {
                // Initialize TonConnect after the script has loaded
                const tonConnect = new TonConnect({
                    project: {
                        name: 'Your App Name',
                        icon: 'path/to/your/icon.png' // Optional: Customize with your app's icon
                    }
                });

                try {
                    // Create a TonConnect client
                    const client = await tonConnect.createClient();
                    
                    // Connect to the wallet
                    const session = await client.connect();
                    
                    // Get wallet address
                    const address = session.walletAddress;
                    
                    // Update status
                    statusElement.innerText = `Connected! Wallet address: ${address}`;
                } catch (error) {
                    console.error('Error connecting wallet:', error);
                    statusElement.innerText = 'Failed to connect wallet. Please try again.';
                }
            };
            document.head.appendChild(script);
        } catch (error) {
            console.error('Error loading TonConnect script:', error);
            statusElement.innerText = 'Failed to load TonConnect. Please try again.';
        }
    });
});
